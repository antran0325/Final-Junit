public class StudentRecordsTestableTestMain {
    public static void main(String[]args){
        StudentRecordsTestableTest test = new StudentRecordsTestableTest();
        test.beforeDrop();
    }
}
